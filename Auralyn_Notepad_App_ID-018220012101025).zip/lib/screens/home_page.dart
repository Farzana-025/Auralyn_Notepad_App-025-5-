
import 'package:flutter/material.dart';
import 'add_note_page.dart';
import 'view_notes_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Auralyn Notepad'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
          children: [
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AddNotePage()),
              ),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple.shade100),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [Icon(Icons.note_add, size: 40), SizedBox(height: 10), Text("Add Note")],
              ),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ViewNotesPage()),
              ),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple.shade100),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [Icon(Icons.notes, size: 40), SizedBox(height: 10), Text("View Notes")],
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple.shade100),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [Icon(Icons.person, size: 40), SizedBox(height: 10), Text("Profile")],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
